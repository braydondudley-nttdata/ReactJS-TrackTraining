import NewMeetupForm from "../components/forms/NewMeetupForm";

function NewMeetupsPage() {

    return (
        <section>
            <h1>New Meetups Page</h1>
            <NewMeetupForm />
        </section>
    );
}

export default NewMeetupsPage;